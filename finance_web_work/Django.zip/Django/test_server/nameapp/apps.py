from django.apps import AppConfig


class NameappConfig(AppConfig):
    name = 'nameapp'
