from django.db import models
from django.utils.translation import ugettext_lazy as _

#Django中数据表为model
class Person(models.Model):
    name = models.CharField(_('Name'), max_length=255, unique=True)#设置字段名称以及长度等参数
    mail = models.EmailField(max_length=255, blank=True)#blank表示允许字段为空
    def __unicode__(self):  #将每个联系人对象表示为字符串形式
            return self.name
            
    class Meta:
               ordering = ['name']
