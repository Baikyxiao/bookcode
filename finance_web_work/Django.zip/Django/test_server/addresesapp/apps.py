from django.apps import AppConfig


class AddresesappConfig(AppConfig):
    name = 'addresesapp'
